JMGRIT Windows 11 → Proxmox Offline Guide v1.2.9

Open index.html in a modern browser. Keep this folder together.

Guide workspace values, completed steps, and scratchpad notes are stored only in local browser storage. Use Import state / Export state to move or back up that local state. Nothing is uploaded to JMGRIT.

Latest living guide: https://jmgrit.com/guides/windows-11-to-proxmox/
