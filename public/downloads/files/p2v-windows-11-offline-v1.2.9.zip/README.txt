JMGRIT Windows 11 → Proxmox Offline Guide v1.2.9

Extract the ZIP and open index.html in a modern browser.
Progress, workspace values, and scratchpad notes are stored only in that browser profile.
Latest online guide: https://jmgrit.com/guides/windows-11-to-proxmox/
